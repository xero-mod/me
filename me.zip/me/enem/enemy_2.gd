extends CharacterBody2D

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
var health: int = 1
func _physics_process(_delta: float) -> void:
	animated_sprite_2d.play("default")
	move_and_slide()

func damge():
	health -= 1
	if health <= 0:
		queue_free()
	


func _on_z_body_entered(body: Node2D) -> void:
	if body.is_in_group("s"):
		body.gam()
		await get_tree().create_timer(0.2).timeout
		queue_free()
	pass # Replace with function body.
