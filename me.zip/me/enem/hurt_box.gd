extends Area2D

@onready var damge = self.get_parent()
func _on_area_entered(area: Area2D) -> void:
	if area is hitBox:
		damge.damges()
	pass # Replace with function body.
