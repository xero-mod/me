extends Area2D


@onready var damges = self.get_parent()




func _on_area_entered(area: Area2D) -> void:
	if area is hitBox:
		damges.damges()
	pass # Replace with function body.
