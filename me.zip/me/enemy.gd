extends CharacterBody2D

@onready var Health: Label = $health
var health = 9
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

func _physics_process(_delta: float) -> void:
	if not is_on_floor():
		velocity.y = 12
	pass
func _ready() -> void:
	animated_sprite_2d.play("default")

func _process(_delta: float) -> void:
	if Health:
		Health.text = str(health)
	
func damges():
	health -= 3
	
	if health <= 0:
		queue_free()


func _on_n_body_entered(body: Node2D) -> void:
	if body.is_in_group("s"):
		body.gam()
		await get_tree().create_timer(0.2).timeout
		queue_free()
	pass # Replace with function body.
