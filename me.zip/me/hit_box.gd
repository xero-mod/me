extends Area2D


@onready var damegs = self.get_parent()
func _on_area_entered(area: Area2D) -> void:
	if area is hitBox:
		damegs.damge()
	pass 
