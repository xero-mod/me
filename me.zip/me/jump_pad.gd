extends Area2D






func _on_body_entered(body: Node2D) -> void:
	if body is player:
		var jump : player = body
		jump.velocity.y = -600
	pass # Replace with function body.
