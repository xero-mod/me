extends CharacterBody2D

var health = 1000
@onready var label: Label = $Label

func _process(delta: float) -> void:
	if label:
		label.text = str(health)
func gam():
	health -= 50
	print(health)
	if health <= 0:
		get_tree().change_scene_to_file("res://ui/ui_1.tscn")
