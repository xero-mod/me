extends Path2D


@export_dir var  enmey: String
@export var watai:float 

@onready var sopnar: Timer = $sopnar
@export var brck: Timer  
@onready var wave: Timer = $wave

func _ready() -> void:
	brck.wait_time = watai
	brck.start()
func _on_sopnar_timeout() -> void:
	var new_enmey = load( enmey).instantiate() 
	add_child(new_enmey)
	pass # Replace with function body.


func _on_wave_timeout() -> void:
	sopnar.stop()
	sopnar.wait_time -= 0.1
	sopnar.wait_time = clamp(sopnar.wait_time, 0.6, 1.0)
	for die in get_tree().get_nodes_in_group("enemy"):
		die.queue_free()
	brck.start()
	
	
	pass # Replace with function body.


func _on_brck_timeout() -> void:
	sopnar.start()
	wave.start()
	pass # Replace with function body.
