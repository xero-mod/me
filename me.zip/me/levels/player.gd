extends CharacterBody2D

class_name player
var speed: int = 150
var  jump: int = -300
var jymp_prom: int = -180
var  gr: int = 12
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
var wailk: int = 1
var shot:bool = false
@onready var animation: AnimationPlayer = $AnimationPlayer
@onready var animation_tree: AnimationTree = $AnimationTree
@onready var phantom: Camera2D = $Camera2D
@onready var sound_run: AudioStreamPlayer = $AudioStreamPlayer
@onready var audio_stream_player: AudioStreamPlayer = $AudioStreamPlayer

func _physics_process(_delta: float) -> void:
	
	move_and_slide()
	move()
	jumpt()
	zoom()


func attack():

	var buolt = preload("res://shoot/bollt.tscn").instantiate()
	buolt.dir = $AnimatedSprite2D.scale.x 
	buolt.global_position = $AnimatedSprite2D/shoot.global_position
	get_tree().root.add_child(buolt)
	

	 


func move():
	var movea = Input.get_axis("a","r")
	if abs(movea) != 1:
		audio_stream_player.play()

	
	if Input.is_action_pressed("r"):
		velocity.x = speed
		sprite.scale.x = 1
		
		 
	
	elif Input.is_action_pressed("a"):
		velocity.x = -speed
		sprite.scale.x = -1
	
	else :
		velocity.x = lerp(velocity.x,0.0,0.1)
		
#
	
	
var is_jump:bool = false
func jumpt():
	
	if not is_on_floor():
		velocity.y += gr
	
	if Input.is_action_just_pressed("jump"):
		 
		is_jump = true
		if is_on_floor():
			velocity.y = jump
		if is_on_wall() and Input.is_action_pressed("a"):
			velocity.y = jymp_prom
			velocity.x = -wailk

		if is_on_wall() and Input.is_action_pressed("r"):
			velocity.y = jymp_prom
			velocity.x = wailk
	if not Input.is_action_pressed("jump") and velocity.y < 0 and is_jump:
		velocity.y = lerp(velocity.y, 0.0, 0.5)
		is_jump = false
		
		
func zoom() -> void:
	if Input.is_action_just_pressed("zoom"):
		if phantom.zoom == Vector2(1,1):
			phantom.zoom.x = 2.6
			phantom.zoom.y = 2.6
		else :
			phantom.zoom.x = 1
			phantom.zoom.y = 1
		
