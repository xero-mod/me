extends Node2D

var enme = preload("res://enem/enemy_3.tscn")
func _process(_delta: float) -> void:
	$AnimatedSprite2D.play("idle")
