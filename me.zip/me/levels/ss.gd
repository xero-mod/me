extends CharacterBody2D

var health = 10000
@onready var label: Label = $Label


func _process(_delta: float) -> void:
	if label:
		label.text = str(health)

func gam():
	health -= 10
	
	health = clamp(health, 0, 10000)
	await get_tree().create_timer(1).timeout
	if health <= 0:
		get_tree().change_scene_to_file("res://ui/ui_1.tscn")
