extends PathFollow2D


var speed: float = 0.1
@onready var path_follow_2d: PathFollow2D = $"."



func _process(delta: float) -> void:
	progress_ratio += delta * speed
	
 #	if enemy_2.health <= 0:
	#	enemy_2.health = 3
	#	progress_ratio = 0
