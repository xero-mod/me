extends Node


@onready var animation_tree: AnimationTree = $"../AnimationTree"

@onready var Player: player = $".."

func _process(_delta: float) -> void:
	var xaxis = Input.get_axis("a","r")
	
	if xaxis == 0:
		animation_tree.set("parameters/Transition/transition_request","state_1")
	else :
		animation_tree.set("parameters/Transition/transition_request","state_2")
	if !Player.is_on_floor():
		animation_tree.set("parameters/on_floor/transition_request","state_1")
		animation_tree.set("parameters/Transition 2/transition_request","state_1")
	else :
		animation_tree.set("parameters/Transition 2/transition_request","state_0")
		animation_tree.set("parameters/on_floor/transition_request","state_0")
	if Input.is_action_just_pressed("shoot"):
		animation_tree.set("parameters/OneShot/request",AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
	pass
