extends CharacterBody2D


var dir: float = 1

@onready var timer = get_tree().create_timer(10).timeout.connect(func ():queue_free())

func _physics_process(_delta: float) -> void:
	velocity.x = 250 * dir
	if velocity.x <0:
		$Sprite2D.flip_h = true
		

	elif velocity.x >0:
		$Sprite2D.flip_h = false
	move_and_slide()

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("p"):
		return
	queue_free()
	if body.is_in_group("enemy"):
		queue_free()
