extends Control




func _on_button_focus_entered() -> void:
	$AudioStreamPlayer.play()
	await get_tree().create_timer(0.5).timeout
	get_tree().change_scene_to_file("res://ui/ui_1.tscn")
	pass # Replace with function body.
