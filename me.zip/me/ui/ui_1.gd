extends Control

@onready var animation_player: AnimationPlayer = $AnimationPlayer





func _on_button_focus_entered() -> void:
	$AudioStreamPlayer.play()
	animation_player.play("new_animation")
	await get_tree().create_timer(0.5).timeout
	get_tree().change_scene_to_file("res://levels/level_1.tscn")
	pass # Replace with function body.


func _on_settings_focus_entered() -> void:
	$AudioStreamPlayer2.play()
	await get_tree().create_timer(0.5).timeout
	get_tree().change_scene_to_file("res://ui/settings.tscn")
	pass # Replace with function body.


func _on_exit_focus_entered() -> void:
	animation_player.play("new_animation_2")
	await get_tree().create_timer(1).timeout
	get_tree().quit()
	pass # Replace with function body.
