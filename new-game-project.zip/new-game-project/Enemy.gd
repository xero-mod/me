extends Enmeystate
class_name Enemy


@export var move_speed := 100





func physics_Update(delta: float) -> void:
	var direction = player.global_position - enemy.global_position
	print(direction.length())
	enemy.velocity = direction.normalized() * move_speed
	#if direction.length() > 250:
	#	Transitioned.emit(self, "idle")
	
	if direction.length() > 250:
		Transitioned.emit(self, "attack")
	if direction.length() < 250:
		Transitioned.emit(self, "attack")
	if direction.length() < 260:
		Transitioned.emit(self, "shoot")
	if direction.length() > 260:
		Transitioned.emit(self, "shoot")



	enemy.velocity.y += 12
	
	enemy.move_and_slide()
