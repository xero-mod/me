extends Area2D

class_name hurtBox

@onready var parent = self.get_parent()




func _on_area_entered(area: Area2D) -> void:
	if area is hitbox:
		parent.damge()
	pass # Replace with function body.
