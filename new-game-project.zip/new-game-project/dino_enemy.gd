extends CharacterBody2D


class_name DinoEnemy
@onready var Helath: Label = $Label
var health = 1000
func _physics_process(delta: float) -> void:
	move_and_slide()
	
	if velocity.length() > 0:
		$AnimationPlayer.play("idle")
	
	if velocity.x > 0:
		$Sprite2D.scale.x = 1
	
	elif velocity.x < 0:
		$Sprite2D.scale.x = -1


	if Helath:
		Helath.text = str(health)

func d():
	health -= 35
	print(health)
