extends Enmeystate

class_name  attack



@onready var animation_player: AnimationPlayer = $"../../AnimationPlayer"




func physics_Update(delta: float) -> void:
	var direction :Vector2 = player.global_position - enemy.global_position
	animation_player.play("attack")
	
	
	#if  direction.length() < 270 :
		#Transitioned.emit(self, "Follow")

	if direction.length() < 50:
		Transitioned.emit(self, "attack")
	
	if direction.length() > 55:
		Transitioned.emit(self, "shoot")
	enemy.velocity.y += 12
	enemy.move_and_slide()
