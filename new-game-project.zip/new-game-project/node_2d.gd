extends Node2D




func _ready() -> void:
	print("Hello World")
