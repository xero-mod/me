extends Node2D

@export var max_health := 10000
var health: float

func _ready() -> void:
	health = max_health
	$"../Label".text = str(health) + "ph"
func damge():
	health -= 35
	print(health)
