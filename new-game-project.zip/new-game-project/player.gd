extends CharacterBody2D



@export  var SPEED = 300.0
@export  var JUMP_VELOCITY = 400.0
@export var  jump = false
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var  anim = $Timer


func _physics_process(delta: float) -> void:
	# Add the gravity.
	velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept")and is_on_floor():
		velocity.y = -JUMP_VELOCITY



	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
		$AnimatedSprite2D.play("run")
	else:
		velocity.x = 0
	
	if velocity.x >0:
		$AnimatedSprite2D.flip_h = true
	
	elif  velocity.x < 0:
		$AnimatedSprite2D.flip_h = false
	velocity.y += 12
	move_and_slide()

func damge():
	print("attt")

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("boss"):
		body.d()
	pass # Replace with function body.
