extends Enmeystate

class_name shoot



@onready var animation_player: AnimationPlayer = $"../../AnimationPlayer"




func physics_Update(delta: float) -> void:
	var direction  = player.global_position - enemy.global_position
	animation_player.play("shoot")
		
	if  direction.length() > 320:
		Transitioned.emit(self, "Follow")

	#if  direction.length() > 22 :
		#Transitioned.emit(self, "attack")

	if direction.length() > 55:
		Transitioned.emit(self, "shoot")
	if direction.length() < 50:
		Transitioned.emit(self, "attack")

	enemy.velocity.y += 12
	enemy.move_and_slide()
