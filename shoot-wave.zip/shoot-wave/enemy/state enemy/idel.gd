extends state_enemy_loop

class_name idle
var move_speed = 10
var move_dirosion
var awiat_time: float


func rng_move_enemy():
	move_dirosion = Vector2(randf_range(-1,1), randf_range(0,0)).normalized()
	awiat_time = randf_range(1, 3)
	
func Enter_emym():
	rng_move_enemy()
	playere = get_tree().get_first_node_in_group("player")

func Updatee(delta):
	if awiat_time >0:
		awiat_time -= 0
	
	else:
		rng_move_enemy()
	
func process_Update(delta: float):
	var diron = playere.global_position - enemyn.global_position
	if enemyn:
		enemyn.velocity = move_dirosion * move_speed
		enemyn.velocity.y += 12

	if diron.length() < 250:
		Tremn.emit(self, "run")
