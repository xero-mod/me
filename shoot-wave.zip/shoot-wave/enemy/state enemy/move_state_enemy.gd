extends state_enemy_loop
class_name run

var speeed: float = 100
 


func process_Update(delta: float):
	var diron = playere.global_position - enemyn.global_position
	
	enemyn.velocity = diron.normalized() * speeed
	
	if diron.length() > 250:
		Tremn.emit(self, "idel")
