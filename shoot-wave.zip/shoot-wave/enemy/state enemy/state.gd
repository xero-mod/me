extends Node

class_name Statem

signal Tremn

func Enter_emym():
	pass

func Eixt_emym():
	pass
func Updatec(_delta: float):
	pass
func process_Update(_delta: float):
	pass
