extends Statem

class_name state_enemy_loop
var playere: CharacterBody2D
@export var enemyn: CharacterBody2D
func _ready() -> void:
	playere = get_tree().get_first_node_in_group("player")
