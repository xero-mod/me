extends Node

@export var instal_state: Statem
var staten: Dictionary = {}
var currt_state: Statem


func _ready() -> void:
	for childr in get_children():
		if childr is Statem:
			staten[childr.name.to_lower()] = childr
			childr.Tremn.connect(in_cild_state)
	
	
	if instal_state:
		instal_state.Enter_emym()
		currt_state = instal_state
	
func _process(delta: float) -> void:
	if currt_state:
		currt_state.Updatec(delta)

func _physics_process(delta: float) -> void:
	if currt_state:
		currt_state.process_Update(delta)

func in_cild_state(state, new_state_nams):
	if state != currt_state:
		return
	 
	var new_state = staten.get(new_state_nams.to_lower())
	
	
	if !new_state:
		currt_state.Eixt_emym()
	
	
	new_state.Enter_emym()
	
	currt_state = new_state
