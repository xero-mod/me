extends state_loop

class_name jump_state
func physics_Update(_delta: float):
	if Input.is_action_pressed("jump"):
		if  playerm.is_on_floor():
			playerm.velocity.y = jump
		
	elif Input.is_action_pressed("left") or Input.is_action_pressed("right"):
		Tram.emit(self, "move")
	
	if Input.is_action_pressed("left"):
		playerm.velocity.x = -speed
	
	if Input.is_action_pressed("right"):
		playerm.velocity.x = speed
