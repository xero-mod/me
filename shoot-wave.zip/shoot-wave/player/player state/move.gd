extends state_loop

class_name move



func physics_Update(_delta: float):
	if Input.is_action_pressed("right"):
		playerm.velocity.x = speed
	
	elif Input.is_action_pressed("left"):
		playerm.velocity.x = -speed
	
	else :
		Tram.emit(self, "idel")
	
	if Input.is_action_pressed("jump"):
		Tram.emit(self, "jump")
	
