extends Node



class_name State
signal Tram

func Enter():
	pass

func Exit():
	pass

func Update(_delta: float):
	pass

func physics_Update(_delta: float):
	pass
