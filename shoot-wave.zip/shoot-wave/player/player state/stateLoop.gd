extends State

class_name state_loop
enum {speed = 250, jump = -300 , gravity = 4}



@export var playerm: CharacterBody2D

func _physics_process(_delta: float) -> void:
	if not playerm.is_on_floor():
		playerm.velocity.y += gravity
