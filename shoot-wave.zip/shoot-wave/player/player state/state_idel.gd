extends state_loop

class_name idel



func idles():
	playerm.velocity.x = 0

func Enter():
	idles()


func physics_Update(_delta: float):
	if Input.is_action_pressed("left") or Input.is_action_pressed("right"):
		Tram.emit(self, "move")
	
	elif Input.is_action_pressed("jump"):
		Tram.emit(self, "jump")
	
