extends CharacterBody2D

class_name player

func _physics_process(_delta: float) -> void:
	move_and_slide()
